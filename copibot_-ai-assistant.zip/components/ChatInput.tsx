import React, { useState } from 'react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const SendIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 20 20"
        fill="currentColor"
        className={className}
        height="18"
        width="18"
    >
        <path d="M3.105 3.105a.75.75 0 01.814-.153l12.044 4.301a.75.75 0 010 1.396l-12.044 4.301a.75.75 0 01-.967-1.242l10.402-3.715L3.96 4.2a.75.75 0 01-.855-.944z" />
    </svg>
);


export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isLoading) {
      onSendMessage(inputValue);
      setInputValue('');
    }
  };

  return (
    <div className="p-3 border-t border-gray-700 flex items-center bg-gray-900">
      <form onSubmit={handleSubmit} className="flex items-center w-full">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Type your message..."
          disabled={isLoading}
          className="flex-1 p-2 bg-gray-800 text-gray-100 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
          aria-label="Chat message input"
        />
        <button
          type="submit"
          disabled={isLoading || !inputValue.trim()}
          className="ml-2 p-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 disabled:bg-gray-700 disabled:cursor-not-allowed flex-shrink-0"
          aria-label="Send message"
        >
          <SendIcon />
        </button>
      </form>
    </div>
  );
};