import React from 'react';
import type { Message } from '../types';
import { Role } from '../types';
import { CodeBlock } from './CodeBlock';

interface ChatBubbleProps {
  message: Message;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === Role.USER;

  const bubbleClasses = isUser
    ? 'bg-indigo-600 text-white rounded-br-none'
    : 'bg-gray-700 text-gray-100 rounded-bl-none';
  
  const containerClasses = isUser ? 'justify-end' : 'justify-start';

  // Split the message text by code blocks denoted by ```
  const parts = message.text.split('```');

  // Don't render a bubble for empty messages
  if (!message.text.trim()) {
    return null;
  }

  return (
    <div className={`flex ${containerClasses}`}>
      <div
        className={`px-4 py-2 rounded-2xl max-w-[85%] ${bubbleClasses}`}
      >
        {parts.map((part, index) => {
          if (index % 2 === 0) {
            // This is a plain text part
            if (!part.trim()) return null;
            return (
              <p key={index} className="whitespace-pre-wrap my-1 first:mt-0 last:mb-0">
                {part.trim()}
              </p>
            );
          } else {
            // This is a code block part
            const firstNewlineIndex = part.indexOf('\n');
            const language = part.substring(0, firstNewlineIndex).trim();
            const code = language ? part.substring(firstNewlineIndex + 1) : part;

            return <CodeBlock key={index} code={code.trim()} language={language} />;
          }
        }).filter(Boolean)}
      </div>
    </div>
  );
};
