import React from 'react';

export const Header: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-indigo-600 to-cyan-500 flex items-center gap-3 p-4 shadow-lg">
      <img
        src="https://cdn-icons-png.flaticon.com/512/4712/4712100.png"
        alt="CopiBot Avatar"
        className="w-12 h-12 rounded-full border-2 border-white shadow-md glow"
      />
      <div>
        <h2 className="font-semibold text-white text-lg">CopiBot Assistant</h2>
        <p className="text-sm text-indigo-100">Powered by AI 💡</p>
      </div>
    </div>
  );
};